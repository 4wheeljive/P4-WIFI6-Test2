#pragma once

#include "fl/utility.h"

namespace fl {

// DefaultLess is now an alias for less<T>, defined in utility.h

} // namespace fl
